<footer class="container-fluid">
	<div class="row">
		<div class="col-md-4"> 
			<p class="direccion">
				Dirección
			</p>
			<p class="texto">
            <i class="fa fa-map-marker" id="localizcion"></i>	
				Calle Tijia 1223,</br>
                Papantla 9932,</br>
                Veracruz, Mexico.
			</p>
		</div>	
		<div class="col-md-4">
			<p class="contacto">
				Contactos 
			</p>
			<p class="texto">
			    Te invitamos a visitarnos para probar nuestros diferentes tacos y brindarte una buena atención, para ellos visitanos a nuestro local o pide tu comida atraves de los siguientes medios:</p>
			<p class="texto">		    
				Por telefono al numero:</br>
                7841231243
			</p>
			<div class="texto">
				<p>
					Por correo a:</br>
                    TACOSLOSHERMANOS@gmail.com
				</p>
			</div>
		</div>
		<div class="col-md-4">
			<p class="contacto">

        </p>
			<p class="titulo-contacto">
                <a href="/"><img src="{{asset('img/Facebook.png')}}" high='50px' width='50px'></a>
                <a href="/"><img src="{{asset('img/instagram.png')}}" high='50px' width='50px'></a>
                <a href="/"><img src="{{asset('img/whatsapp.png')}}" high='50px' width='50px'></a>
			</p>
		</div>
</div>
	<div id="pie-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="titulo_footer">
						| Copyrigh ©2022 All rights reserved | 
					</p>
				</div>
				
			</div>
		</div>
	</div>
	
</footer>